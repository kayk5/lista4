﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{
    internal class Questao10
    {
        static int Idade()
        {
            int idade;
            Console.WriteLine(" qual a idade do nadador?");
            idade = int.Parse(Console.ReadLine());

            return idade;


        }

        public static void Rodar()
        {

            int categoria = 0;

            categoria = Idade();

            if ((categoria >= 5) && (categoria <= 7))
                Console.WriteLine("a categoria do atleta é F");
            else if ((categoria >= 8) && (categoria <= 10))
                Console.WriteLine("a categoria do atleta é E");
            else if ((categoria >= 11) && (categoria <= 13))
                Console.WriteLine("a categoria do atleta é D");
            else if ((categoria >= 14) && (categoria <= 15))
                Console.WriteLine("a categoria do atleta é C");
            else if ((categoria >= 16) && (categoria <= 17))
                Console.WriteLine("a categoria do atleta é B");
            else if (categoria >=18)
                Console.WriteLine("a categoria do atleta é A");


        }
    }
}
