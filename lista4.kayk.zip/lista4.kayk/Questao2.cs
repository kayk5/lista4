﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{
    internal class Questao2
    {
        static double Media(double x, int y)
        {
            double z = 0;
            z = x / y;
            return z;
        }

        public static void Rodar()
        {
            double salario, salariototal = 0, filhos;
            int pessoas = 0;
            char resposta;
            do
            {
                Console.Write("qual o seu salario? R$");
                salario = double.Parse(Console.ReadLine());

                pessoas++;
                salariototal += salario;

                Console.WriteLine("quantos filhos voce tem?");
                filhos = double.Parse(Console.ReadLine());

                Console.WriteLine("deseja continuar? <s/n>");
                resposta = char.Parse(Console.ReadLine());

            } while (resposta == 's');

            Console.WriteLine("a média salarial é de R$" + Media(salariototal, pessoas));

        }
    }
}
