﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{
internal class Program
    {
        private static void Main(string[] args)
        {
         Console.WriteLine("Hello, World!");
         //Questao1.Rodar();
         //Questao2.Rodar();
         Questao3.Rodar();
         //Questao4.Rodar();
         //Questao5.Rodar();
         //Questao6.Rodar();
         //Questao7.Rodar();
         //Questao8.Rodar();
         //Questao9.Rodar();
         //Questao10.Rodar();


        }




}
    
}