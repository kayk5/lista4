﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{
    internal class Questao5
    {
        static int MDC (int a, int b)
        {
            int r = 0;
            while(b!=0)
            {
                r = a % b;
                a = b;
                b = r;
            }
            return a;
        }

        public static void Rodar()
        {
            int x,y;
            Console.WriteLine("digite dois numeros para calcular o seu MDC:");
            x = int.Parse(Console.ReadLine());
            y = int.Parse(Console.ReadLine());
            Console.WriteLine("o MDC de {0} e {1} é: {2}", x, y, MDC(x, y));

        }
    }
}
