﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{
    internal class Questao1
    {
        static void nota(int n1, int n2, int n3, char letra)
        {
            double notafinal = 0;

            switch (letra)
            {
                case 'a':
                    notafinal = (double)(n1 + n2 + n3) / 3;
                    Console.WriteLine("nota:" + notafinal);
                    break;

                case 'p':
                    notafinal = (double)(n1 * 5 + n2 * 3 + n3 * 2) / 10;
                    Console.WriteLine("nota:" + notafinal);
                    break;

                default:
                    Console.WriteLine("opçao invalida!");
                    break;


            }



        }
        public static void Rodar()
        {
            int n, nota1, nota2, nota3;
            char r;

            Console.WriteLine(" digite a quantidade de alunos");
            n = int.Parse(Console.ReadLine());

            for (int x = 1; x <= n; x++)
            {
                Console.WriteLine(" nota 1 do aluno {0}", x);
                nota1 = int.Parse(Console.ReadLine());

                Console.WriteLine(" nota 2 do aluno {0}", x);
                nota2 = int.Parse(Console.ReadLine());

                Console.WriteLine(" nota 3 do aluno {0}", x);
                nota3 = int.Parse(Console.ReadLine());

                Console.WriteLine(" tipo de media a ou p");
                r = char.Parse(Console.ReadLine());

                nota(nota1, nota2, nota3, r);

            }
        }
    }
}

