﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{
    internal class Questao7
    {
        static char Comparacao(int media)
        {
            char conceito=' ';
            if (media <= 39)
                conceito = 'F';
            else if ((media >= 40) && (media <= 59))
                conceito = 'E';
            else if ((media >= 60) && (media <= 69))
                conceito = 'D';
            else if ((media >= 70) && (media <= 79))
                conceito = 'C';
            else if ((media >= 80) && (media <= 89))
                conceito = 'B';
            else if (media >= 90)
                conceito = 'A';

            return conceito;
        }
        public static void Rodar()
        {
            int b=1, nota;
            do
            {
                Console.WriteLine("qual a média do aluno?");
                nota = int.Parse(Console.ReadLine());
                Console.WriteLine("A média do aluno foi {0} e seu conceito: {1}", nota, Comparacao(nota));

            } while (b != 0);
        }
    }
}
