﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{
    internal class Questao6
    {
        static bool Comparacao(int b)
        {
            return (b % 2 == 0);
        }
        public static void Rodar()
        {
            int a = 1, b;
            do
            {
              Console.WriteLine("digite um numero para saber se é par: " );
              b = int.Parse( Console.ReadLine());
                Console.WriteLine("{0}", Comparacao(b));

            } while (a != 0);

        }
    }
}
