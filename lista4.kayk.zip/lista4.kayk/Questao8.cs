﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{
    internal class Questao8
    {
        static void Equacao(double n)
        {
            double s = 0, S=0;
            for (int x = 1; x <= n; x++) 
            {
                s = (Math.Pow(x, 2) + 1) / (x + 3);
                Console.WriteLine("({0}² + 1) / ({0} + 3) = {1:F2}", x, s);
                S += s;
            
            }
            Console.WriteLine(" o valor final da equação é {0:F2}", S);


        }

        public static void Rodar()
        {
            int x ;
            Console.WriteLine("digite um numero para ser calculado pela equação (n²+1)/(n+3)");
            x = int.Parse(Console.ReadLine()); 
            Equacao(x);
            
        }
    }
}
