﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{
    internal class Questao9
    {
        public static void Rodar()
        {
            int alunos;
            Console.WriteLine("insira a quantidade de alunos:");
            alunos = int.Parse(Console.ReadLine());
            for (int x = 1; x <= alunos; x++)
            {

                Console.WriteLine("a media do aluno {0} foi {1}", x, Notas(alunos));
            }
            
            
        }

        static int Notas(int alunos)
        {
            double notas, notastotais=0, medianotas=0, i=0;
            int resposta;
            do 
            {
                Console.WriteLine(" digite a nota do aluno:");
                notas = double.Parse(Console.ReadLine());
                notastotais += notas;
                i++;

                Console.WriteLine("deseja continuar? <s/n>");
                resposta = char.Parse(Console.ReadLine());

            } while (resposta == 's');
            medianotas = notastotais / i;

            if (medianotas <= 6)
                Console.WriteLine("REPROVADO!");
            else
                Console.WriteLine("APROVADO");

            return (int)medianotas;
        }
    }
}
