﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace lista4._1
{
    internal class Questao3
    {
        public static void Numeros()
        {
            int a, b, c;
            Console.WriteLine(" digite tres numeros inteiros:");
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            c = int.Parse(Console.ReadLine());
            Comparacao(a, b, c);


        }

        static void Comparacao(int a,int b ,int c)
        {
            if (a > b)
            {
                if (b > c) 
                    Console.WriteLine("A ordem crescente é: {0},{1},{2}",c,b,a);

                else if (a > c) 
                    Console.WriteLine("A ordem crescente é: {0},{1},{2}", b,c,a);

                else 
                    Console.WriteLine("A ordem crescente é: {0},{1},{2}", b,a,c);
            }
            else if (b > c)
            {
                if (a > c) 
                    Console.WriteLine("A ordem crescente é: {0},{1},{2}", c,a,b);
                else 
                    Console.WriteLine("A ordem crescente é: {0},{1},{2}", a,c,b);
            }
            else Console.WriteLine("A ordem crescente é: {0},{1},{2}", a,b,c);
        }

        public static void Rodar()

        {
            int n;
            Console.WriteLine("quantas vezes deseja fazer esse procedimento?");
            n = int.Parse(Console.ReadLine()); 

            for (int x = 0; x < n; x++)
            {
               
                Numeros();



            }

        }
    }
}
