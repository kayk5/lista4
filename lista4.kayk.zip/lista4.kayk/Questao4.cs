﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista4._1
{

    internal class Questao4
    {
         static void Numeros()
        {
            int a, b, c;
            Console.WriteLine(" os lados do triangulo:");
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            c = int.Parse(Console.ReadLine());

            Comparacao(a, b, c);


        }

        static void Comparacao(int a, int b, int c)
        {
            if ((c < a + b) && (b < a + c) && (a < b + c))
            {
                Console.WriteLine("triangulo real");
             if ((a == b) && (b == c))
                Console.WriteLine("triangulo equilátero");
             else if ((a == b) || (b == c))
                Console.WriteLine("triangulo isósceles");
             else
                Console.WriteLine("triangulo escaleno");
            }
            else Console.WriteLine("triangulo inexistente");

        }

        public static void Rodar()
        {

            int n = 1;

            do
            {
                Numeros();



            } while (n != 0);
        }
    }

}
